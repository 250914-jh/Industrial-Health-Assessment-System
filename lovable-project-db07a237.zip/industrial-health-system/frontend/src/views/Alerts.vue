<template>
  <div class="page">
    <div class="card">
      <h3 style="margin:0 0 12px">预警记录（共 {{ total }} 条）</h3>
      <el-table :data="list" border stripe size="small">
        <el-table-column prop="id" label="ID" width="80" />
        <el-table-column label="预警等级" width="120">
          <template #default="{ row }">
            <el-tag :type="row.level==='fault' ? 'danger' : 'warning'" effect="dark">
              {{ row.level==='fault' ? '故障' : '警告' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="predicted" label="预测标签" width="120" />
        <el-table-column label="置信度" width="120">
          <template #default="{ row }">{{ (row.confidence*100).toFixed(2) }}%</template>
        </el-table-column>
        <el-table-column label="设备参数" min-width="400">
          <template #default="{ row }">
            <span v-for="(v,k) in JSON.parse(row.featuresJson)" :key="k" style="margin-right:12px">
              <b>{{ k }}</b>: {{ v }}
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="createdAt" label="时间" width="180" />
      </el-table>
      <el-pagination
        style="margin-top:12px;justify-content:flex-end;display:flex"
        v-model:current-page="page" :page-size="size"
        :total="total" layout="prev, pager, next, total"
        @current-change="load" />
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import api from '../api'

const list = ref([])
const total = ref(0)
const page = ref(1)
const size = ref(20)

async function load() {
  const res = await api.get('/alerts', { params: { page: page.value - 1, size: size.value } })
  list.value = res.content
  total.value = res.totalElements
}
onMounted(load)
</script>
