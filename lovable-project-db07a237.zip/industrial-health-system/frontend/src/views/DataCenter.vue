<template>
  <div class="page">
    <div class="card">
      <h3 style="margin:0 0 12px">CSV 数据集上传</h3>
      <el-upload
        :before-upload="beforeUpload"
        :http-request="upload"
        :show-file-list="false"
        drag accept=".csv">
        <el-icon class="el-icon--upload" style="font-size:48px;color:#1976d2"><UploadFilled/></el-icon>
        <div>将 CSV 文件拖到此处，或<em>点击上传</em></div>
        <template #tip>
          <div style="color:#888;margin-top:6px">
            需包含列：<el-tag v-for="f in schema.features" :key="f" size="small" style="margin:2px">{{ f }}</el-tag>
            标签列：<el-tag size="small" type="warning">{{ schema.label }}</el-tag>
            标签取值：<el-tag v-for="l in schema.labels" :key="l" size="small" type="info" style="margin:2px">{{ l }}</el-tag>
          </div>
        </template>
      </el-upload>
    </div>

    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
        <h3 style="margin:0">采集数据列表（共 {{ total }} 条）</h3>
        <el-button type="danger" plain size="small" @click="clear">清空数据</el-button>
      </div>
      <el-table :data="list" border stripe size="small">
        <el-table-column type="index" width="60" />
        <el-table-column label="特征" min-width="400">
          <template #default="{ row }">
            <span v-for="(v,k) in JSON.parse(row.featuresJson)" :key="k" style="margin-right:12px">
              <b>{{ k }}</b>: {{ v }}
            </span>
          </template>
        </el-table-column>
        <el-table-column label="标签" width="100">
          <template #default="{ row }">
            <el-tag :type="row.label==='fault'?'danger':row.label==='warning'?'warning':'success'">{{ row.label }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="collectedAt" label="采集时间" width="180" />
      </el-table>
      <el-pagination
        style="margin-top:12px;justify-content:flex-end;display:flex"
        v-model:current-page="page" :page-size="size"
        :total="total" layout="prev, pager, next, total"
        @current-change="load" />
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { UploadFilled } from '@element-plus/icons-vue'
import api from '../api'

const list = ref([])
const total = ref(0)
const page = ref(1)
const size = ref(20)
const schema = ref({ features: [], label: '', labels: [] })

function beforeUpload(file) {
  if (!file.name.endsWith('.csv')) { ElMessage.error('只支持 CSV 文件'); return false }
  return true
}

async function upload({ file }) {
  const fd = new FormData(); fd.append('file', file)
  const res = await api.post('/data/upload', fd, { headers: { 'Content-Type': 'multipart/form-data' } })
  ElMessage.success(`导入 ${res.imported} 条，库内共 ${res.total} 条`)
  page.value = 1
  load()
}

async function clear() {
  await api.delete('/data/all')
  ElMessage.success('已清空')
  load()
}

async function load() {
  const res = await api.get('/data/list', { params: { page: page.value - 1, size: size.value } })
  list.value = res.content
  total.value = res.totalElements
}

onMounted(async () => {
  schema.value = await api.get('/data/schema')
  load()
})
</script>
