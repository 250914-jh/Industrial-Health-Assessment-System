<template>
  <div class="page">
    <el-row :gutter="16">
      <el-col :span="6"><div class="stat-card ok"><div>总采集数据</div><div class="num">{{ stats.totalRecords || 0 }}</div></div></el-col>
      <el-col :span="6"><div class="stat-card"><div>预警总数</div><div class="num">{{ stats.totalAlerts || 0 }}</div></div></el-col>
      <el-col :span="6"><div class="stat-card warn"><div>警告级</div><div class="num">{{ stats.alertDistribution?.warning || 0 }}</div></div></el-col>
      <el-col :span="6"><div class="stat-card fault"><div>故障级</div><div class="num">{{ stats.alertDistribution?.fault || 0 }}</div></div></el-col>
    </el-row>

    <el-row :gutter="16" style="margin-top:16px">
      <el-col :span="12">
        <div class="card">
          <h3 style="margin:0 0 12px">设备健康状态分布</h3>
          <v-chart :option="pieOption" style="height:320px" autoresize />
        </div>
      </el-col>
      <el-col :span="12">
        <div class="card">
          <h3 style="margin:0 0 12px">特征重要性（决策树）</h3>
          <v-chart v-if="modelInfo.trained" :option="barOption" style="height:320px" autoresize />
          <el-empty v-else description="模型尚未训练" :image-size="100" />
        </div>
      </el-col>
    </el-row>

    <div class="card">
      <h3 style="margin:0 0 12px">模型信息</h3>
      <el-descriptions :column="4" border>
        <el-descriptions-item label="训练状态">
          <el-tag :type="modelInfo.trained ? 'success' : 'info'">{{ modelInfo.trained ? '已训练' : '未训练' }}</el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="准确率">{{ (modelInfo.accuracy * 100).toFixed(2) }}%</el-descriptions-item>
        <el-descriptions-item label="训练集">{{ modelInfo.trainSize }}</el-descriptions-item>
        <el-descriptions-item label="测试集">{{ modelInfo.testSize }}</el-descriptions-item>
      </el-descriptions>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import VChart from 'vue-echarts'
import 'echarts'
import api from '../api'

const stats = ref({})
const modelInfo = ref({ trained: false, accuracy: 0, trainSize: 0, testSize: 0, featureImportance: {} })

const pieOption = computed(() => ({
  tooltip: { trigger: 'item' },
  legend: { bottom: 0 },
  series: [{
    type: 'pie', radius: ['40%','70%'],
    data: Object.entries(stats.value.labelDistribution || {}).map(([name, value]) => ({ name, value })),
    label: { formatter: '{b}: {c}' }
  }]
}))

const barOption = computed(() => {
  const imp = modelInfo.value.featureImportance || {}
  const names = Object.keys(imp), vals = Object.values(imp)
  return {
    tooltip: {}, grid: { left: 100 },
    xAxis: { type: 'value' },
    yAxis: { type: 'category', data: names },
    series: [{ type: 'bar', data: vals, itemStyle: { color: '#1976d2' } }]
  }
})

async function load() {
  stats.value = await api.get('/dashboard/stats')
  modelInfo.value = await api.get('/model/info')
}
onMounted(load)
</script>
