<template>
  <div class="page">
    <div class="card">
      <h3 style="margin:0 0 12px">实时健康评估</h3>
      <p style="color:#666">输入当前设备传感器参数，决策树模型将实时给出健康状态判断；若判定为警告或故障，自动写入预警中心。</p>
      <el-form :model="form" label-width="140px" inline>
        <el-form-item v-for="f in schema.features" :key="f" :label="f">
          <el-input-number v-model="form[f]" :precision="3" :step="0.1" style="width:200px" />
        </el-form-item>
      </el-form>
      <el-button type="primary" size="large" :loading="loading" @click="predict">
        <el-icon><Aim/></el-icon>&nbsp;开始评估
      </el-button>
    </div>

    <div class="card" v-if="result">
      <h3 style="margin:0 0 12px">评估结果</h3>
      <el-result
        :icon="result.label==='normal' ? 'success' : result.label==='warning' ? 'warning' : 'error'"
        :title="resultText"
        :sub-title="`置信度 ${(result.confidence*100).toFixed(2)}%`">
        <template #extra>
          <el-tag v-if="result.alert" type="danger" size="large">⚠ 已自动写入预警中心</el-tag>
          <el-tag v-else type="success" size="large">设备运行正常</el-tag>
        </template>
      </el-result>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { Aim } from '@element-plus/icons-vue'
import api from '../api'

const schema = ref({ features: [] })
const form = reactive({})
const result = ref(null)
const loading = ref(false)

const resultText = computed(() => {
  if (!result.value) return ''
  return { normal: '✅ 设备健康状态：正常', warning: '⚠️ 设备健康状态：警告', fault: '❌ 设备健康状态：故障' }[result.value.label] || result.value.label
})

async function predict() {
  loading.value = true
  try {
    result.value = await api.post('/predict', form)
  } finally {
    loading.value = false
  }
}

onMounted(async () => {
  schema.value = await api.get('/data/schema')
  schema.value.features.forEach(f => { form[f] = 0 })
})
</script>
