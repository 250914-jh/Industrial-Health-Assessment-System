<template>
  <div class="page">
    <div class="card">
      <h3 style="margin:0 0 12px">决策树模型训练</h3>
      <p style="color:#666">使用 Smile ML 的 CART 决策树算法，对采集到的设备历史数据进行训练，自动按 8:2 切分训练集与测试集，并计算准确率和特征重要性。</p>
      <el-button type="primary" size="large" :loading="loading" @click="train">
        <el-icon><DataAnalysis/></el-icon>&nbsp;开始训练模型
      </el-button>
    </div>

    <div class="card" v-if="info.trained">
      <h3 style="margin:0 0 12px">训练结果</h3>
      <el-row :gutter="16">
        <el-col :span="6"><el-statistic title="准确率" :value="(info.accuracy*100).toFixed(2)" suffix="%" /></el-col>
        <el-col :span="6"><el-statistic title="训练集" :value="info.trainSize" /></el-col>
        <el-col :span="6"><el-statistic title="测试集" :value="info.testSize" /></el-col>
        <el-col :span="6"><el-statistic title="最近训练" :value="time" /></el-col>
      </el-row>
      <h4>特征重要性</h4>
      <v-chart :option="barOption" style="height:300px" autoresize />
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import VChart from 'vue-echarts'
import 'echarts'
import { ElMessage } from 'element-plus'
import { DataAnalysis } from '@element-plus/icons-vue'
import api from '../api'

const info = ref({ trained: false })
const loading = ref(false)

const barOption = computed(() => {
  const imp = info.value.featureImportance || {}
  return {
    tooltip: {}, grid: { left: 100 },
    xAxis: { type: 'value' },
    yAxis: { type: 'category', data: Object.keys(imp) },
    series: [{ type: 'bar', data: Object.values(imp), itemStyle: { color: '#42a5f5' } }]
  }
})

const time = computed(() => info.value.lastTrainAt ? new Date(info.value.lastTrainAt).toLocaleString() : '-')

async function train() {
  loading.value = true
  try {
    info.value = await api.post('/model/train')
    ElMessage.success(`训练完成，准确率 ${(info.value.accuracy*100).toFixed(2)}%`)
  } finally {
    loading.value = false
  }
}

onMounted(async () => { info.value = await api.get('/model/info') })
</script>
