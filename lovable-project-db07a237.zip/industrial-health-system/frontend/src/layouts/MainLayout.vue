<template>
  <el-container style="height: 100vh">
    <el-aside width="220px" style="background:#001529;color:#fff">
      <div style="height:60px;display:flex;align-items:center;justify-content:center;font-size:16px;font-weight:600;border-bottom:1px solid #1f3a55">
        🏭 设备健康评估
      </div>
      <el-menu :default-active="$route.path" router background-color="#001529" text-color="#cfd8dc" active-text-color="#42a5f5">
        <el-menu-item index="/dashboard"><el-icon><Monitor/></el-icon><span>健康大屏</span></el-menu-item>
        <el-menu-item index="/data"><el-icon><Upload/></el-icon><span>数据采集</span></el-menu-item>
        <el-menu-item index="/model"><el-icon><DataAnalysis/></el-icon><span>模型训练</span></el-menu-item>
        <el-menu-item index="/predict"><el-icon><Aim/></el-icon><span>健康评估</span></el-menu-item>
        <el-menu-item index="/alerts"><el-icon><Bell/></el-icon><span>预警中心</span></el-menu-item>
      </el-menu>
    </el-aside>
    <el-container>
      <el-header style="background:#fff;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid #eee">
        <div style="font-size:16px;font-weight:500">{{ $route.meta.title || '工业设备健康状态评估系统' }}</div>
        <div>
          <el-tag type="info" style="margin-right:12px">{{ username }}</el-tag>
          <el-button size="small" @click="logout">退出</el-button>
        </div>
      </el-header>
      <el-main style="background:#f0f2f5">
        <router-view />
      </el-main>
    </el-container>
  </el-container>
</template>

<script setup>
import { useRouter } from 'vue-router'
import { Monitor, Upload, DataAnalysis, Aim, Bell } from '@element-plus/icons-vue'

const router = useRouter()
const username = localStorage.getItem('username') || ''

function logout() {
  localStorage.clear()
  router.push('/login')
}
</script>
