import { createRouter, createWebHistory } from 'vue-router'

const routes = [
  { path: '/login', component: () => import('../views/Login.vue') },
  {
    path: '/',
    component: () => import('../layouts/MainLayout.vue'),
    redirect: '/dashboard',
    children: [
      { path: 'dashboard', component: () => import('../views/Dashboard.vue'), meta: { title: '健康大屏' } },
      { path: 'data', component: () => import('../views/DataCenter.vue'), meta: { title: '数据采集' } },
      { path: 'model', component: () => import('../views/ModelCenter.vue'), meta: { title: '模型训练' } },
      { path: 'predict', component: () => import('../views/Predict.vue'), meta: { title: '健康评估' } },
      { path: 'alerts', component: () => import('../views/Alerts.vue'), meta: { title: '预警中心' } }
    ]
  }
]

const router = createRouter({ history: createWebHistory(), routes })

router.beforeEach((to, _, next) => {
  const token = localStorage.getItem('token')
  if (to.path !== '/login' && !token) next('/login')
  else next()
})

export default router
